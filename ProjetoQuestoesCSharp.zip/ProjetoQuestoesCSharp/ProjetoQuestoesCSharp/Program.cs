﻿using System;

namespace ProjetoQuestoesCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.ExibirMenu();
        }
    }
}
