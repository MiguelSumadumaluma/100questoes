# Exercícios em C#

Este projeto é uma coleção de desafios programáticos desenvolvidos em C#. Cada desafio pode ser acessado por meio de um menu interativo na interface de console.

## Instruções para Rodar o Projeto

Garanta que o .NET SDK esteja instalado em seu computador. Para confirmar a instalação, você pode executar o comando "dotnet --version" no terminal. 

Utilize o comando git para clonar o repositório em sua máquina, usando "git clone <URL_DO_REPOSITORIO>" e em seguida acesse o diretório com "cd <NOME_DO_DIRETORIO>". 

Acesse o diretório do projeto e compile-o utilizando o comando "dotnet build". Depois da compilação, você pode iniciar o programa com "dotnet run".

O menu principal será exibido na tela do console. Insira o número do desafio que deseja executar e pressione Enter. Siga as instruções apresentadas para fornecer os dados necessários. Após a execução do desafio, o programa o levará de volta ao menu principal.

Este projeto inclui uma variedade de desafios, tais como:

- Calcular a média de notas de alunos e determinar se foram aprovados com base em uma média maior ou igual a 7.
- Criar um programa que gera números aleatórios e exibe o menor e o maior número entre eles.
- Desenvolver uma função que conta quantas vogais existem em uma frase fornecida pelo usuário.
